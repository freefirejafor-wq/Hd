import crypto from "crypto";
import http from "http";
import http2 from "http2";
import { Readable } from "stream";

const PORT = Number(process.env.PORT) || 3000;
const MASTER_SECRET = "CinePulse_AES256_Master_Key_v4_9x7A2mK8pQ4wL1zR6vN3jH5bT0yF";
const AES_KEY = crypto.createHash("sha256").update(MASTER_SECRET).digest();

function verifyTrialApiKey(rawKey) {
  const key = String(rawKey || "").trim();
  if (!key.startsWith("cp_tr1_")) return false;
  const body = key.slice(7);
  const dot = body.indexOf(".");
  if (dot <= 0) return false;
  const payloadB64 = body.slice(0, dot);
  const sig = body.slice(dot + 1);
  if (!payloadB64 || !sig) return false;
  try {
    const expectedSig = crypto
      .createHmac("sha256", AES_KEY)
      .update("trial-key::" + payloadB64)
      .digest("base64url")
      .slice(0, 22);
    if (sig !== expectedSig) return false;
    const parsed = JSON.parse(Buffer.from(payloadB64, "base64url").toString("utf8"));
    if (!parsed || typeof parsed.e !== "number") return false;
    if (Date.now() >= parsed.e) return false;
    return true;
  } catch {
    return false;
  }
}

function decodeGatewayToken(token) {
  const trimmed = String(token || "").trim();
  if (!trimmed) return "";
  try {
    if (trimmed.startsWith("cp1.")) {
      const parts = trimmed.split(".");
      if (parts.length === 4) {
        const iv = Buffer.from(parts[1], "base64url");
        const tag = Buffer.from(parts[2], "base64url");
        const cipher = Buffer.from(parts[3], "base64url");
        const decipher = crypto.createDecipheriv("aes-256-gcm", AES_KEY, iv);
        decipher.setAuthTag(tag);
        return Buffer.concat([decipher.update(cipher), decipher.final()]).toString("utf8");
      }
    }
    return Buffer.from(trimmed, "base64url").toString("utf8");
  } catch {
    return "";
  }
}

function setCors(res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Range, Content-Type, Accept, X-API-Key");
  res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges, Content-Type, Content-Disposition");
  res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
}

async function resolveEpisodeMp4Url(subjectId, detailPath, se, ep, preferredQ) {
  const attempts = [[se, ep], ...(se === 0 && ep === 0 ? [[1, 1]] : [[0, 0]])];
  for (const [sNum, eNum] of attempts) {
    try {
      const playUrl = "https://h5-api.aoneroom.com/wefeed-h5api-bff/subject/play?subjectId=" + encodeURIComponent(subjectId) + "&se=" + sNum + "&ep=" + eNum + "&detailPath=" + encodeURIComponent(detailPath) + "&streamSignType=1";
      const r = await fetch(playUrl, {
        headers: {
          Accept: "application/json",
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
          Referer: "https://movie-box.co/movies/" + detailPath + "?id=" + subjectId,
          "X-Client-Info": JSON.stringify({ timezone: "Asia/Dhaka" }),
          "X-Vip-Restrict": "0",
          "X-No-High-Risk-Restrict": "1",
          "X-Request-Lang": "en",
        },
        signal: AbortSignal.timeout(6000),
      });
      if (!r.ok) continue;
      const json = await r.json();
      const streams = Array.isArray(json?.data?.streams) ? json.data.streams.filter((x) => x?.url) : [];
      if (!streams.length) continue;
      const pick =
        streams.find((x) => Number(x.resolutions) === preferredQ) ||
        streams.find((x) => Number(x.resolutions) === 480) ||
        streams.find((x) => Number(x.resolutions) === 720) ||
        streams[0];
      if (pick?.url) return String(pick.url);
    } catch {}
  }
  return "";
}

function tryHttp2Pipe(req, res, targetUrl, hdrs, isDl, dlName) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (ok) => {
      if (!settled) {
        settled = true;
        resolve(ok);
      }
    };
    let parsed;
    try { parsed = new URL(targetUrl); } catch { return done(false); }
    if (parsed.protocol !== "https:") return done(false);
    let client;
    try { client = http2.connect(parsed.origin); } catch { return done(false); }
    const close = () => { try { if (!client.destroyed) client.close(); } catch {} };
    const timer = setTimeout(() => { close(); done(false); }, 8000);
    client.on("error", () => { clearTimeout(timer); close(); done(false); });
    const reqHdrs = { ":method": req.method === "HEAD" ? "HEAD" : "GET", ":path": parsed.pathname + parsed.search };
    for (const [k, v] of Object.entries(hdrs)) {
      if (v) reqHdrs[k.toLowerCase()] = v;
    }
    const h2Req = client.request(reqHdrs);
    h2Req.on("error", () => {
      clearTimeout(timer);
      close();
      if (res.headersSent && !res.writableEnded) res.end();
      done(false);
    });
    h2Req.on("response", (rh) => {
      clearTimeout(timer);
      const status = Number(rh[":status"] || 0);
      if (status !== 200 && status !== 206) {
        h2Req.close();
        close();
        return done(false);
      }
      const ct = String(rh["content-type"] || "video/mp4").split(";")[0].trim();
      res.statusCode = status;
      res.setHeader("Content-Type", ct.includes("octet-stream") ? "video/mp4" : ct);
      res.setHeader("Accept-Ranges", "bytes");
      res.setHeader("Cache-Control", "public, max-age=3600");
      if (rh["content-length"]) res.setHeader("Content-Length", String(rh["content-length"]));
      if (rh["content-range"]) res.setHeader("Content-Range", String(rh["content-range"]));
      if (isDl) res.setHeader("Content-Disposition", "attachment; filename=\"" + dlName + "\"");
      if (req.method === "HEAD") {
        h2Req.close();
        close();
        res.end();
        return done(true);
      }
      res.on("close", () => {
        try { if (!h2Req.destroyed) h2Req.close(); } catch {}
        close();
      });
      h2Req.on("end", close);
      h2Req.pipe(res);
      done(true);
    });
    h2Req.end();
  });
}

const server = http.createServer(async (req, res) => {
  setCors(res);
  if (req.method === "OPTIONS") {
    res.statusCode = 204;
    return res.end();
  }

  const url = new URL(req.url || "/", "http://" + (req.headers.host || "localhost"));
  const pathName = url.pathname;

  if (pathName === "/" || pathName === "/health" || pathName === "/api/health") {
    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ ok: true, service: "CinePulse Node Stream Proxy", version: 2, status: "ACTIVE" }));
  }

  const isVideo = pathName === "/api/mb-stream" || pathName === "/api/mb-stream.mp4";
  const isEpVideo = pathName === "/api/mb-ep-stream" || pathName === "/api/mb-ep-stream.mp4";
  const isSub = pathName === "/api/mb-subtitle-srt";

  if (!isVideo && !isEpVideo && !isSub) {
    res.statusCode = 404;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ ok: false, error: "Invalid route" }));
  }

  const tk = url.searchParams.get("tk") || String(req.headers["x-api-key"] || "");
  if (!verifyTrialApiKey(tk)) {
    res.statusCode = 403;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ ok: false, error: "Valid active API key (?tk=) required." }));
  }

  let primaryUrl = "";
  let fallbackUrl = "";
  if (isEpVideo) {
    const subjectId = (url.searchParams.get("subjectId") || "").trim();
    const detailPath = (url.searchParams.get("detailPath") || "movie").trim();
    const se = Math.max(0, parseInt(url.searchParams.get("se") || "1", 10) || 0);
    const ep = Math.max(0, parseInt(url.searchParams.get("ep") || "1", 10) || 0);
    const q = parseInt(url.searchParams.get("q") || "480", 10) || 480;
    if (subjectId) primaryUrl = await resolveEpisodeMp4Url(subjectId, detailPath, se, ep, q);
    fallbackUrl = decodeGatewayToken(url.searchParams.get("fb") || "");
  } else {
    primaryUrl = decodeGatewayToken(url.searchParams.get("t") || "");
    fallbackUrl = decodeGatewayToken(url.searchParams.get("fb") || "");
  }

  const candidates = [primaryUrl, fallbackUrl].filter((u) => /^https?:\/\//i.test(u));
  if (!candidates.length) {
    res.statusCode = 400;
    res.setHeader("Content-Type", "application/json");
    return res.end(JSON.stringify({ ok: false, error: "Invalid media token" }));
  }

  const chromeUa = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
  const rangeHdr = req.headers.range ? String(req.headers.range) : "";
  const baseReqHdr = (isVideo || isEpVideo) && rangeHdr ? { Range: rangeHdr, Accept: "*/*" } : { Accept: "*/*" };
  const headerVariants = [
    { ...baseReqHdr, "User-Agent": chromeUa, Referer: "https://movie-box.co/", "Accept-Language": "en-US,en;q=0.9" },
    { ...baseReqHdr, "User-Agent": chromeUa, Referer: "https://123movienow.cc/", "Accept-Language": "en-US,en;q=0.9" },
    { ...baseReqHdr, "User-Agent": "okhttp/4.12.0", Referer: "https://movie-box.co/" },
  ];

  const isDl = url.searchParams.get("dl") === "1";
  const rawName = (url.searchParams.get("name") || "movie.mp4").replace(/[^a-zA-Z0-9._-]+/g, "_");
  const dlName = rawName.toLowerCase().endsWith(".mp4") ? rawName : rawName + ".mp4";

  let lastStatus = 502;
  for (const target of candidates) {
    for (const hdrs of headerVariants) {
      const ac = new AbortController();
      const hdrTimer = setTimeout(() => ac.abort(), 9000);
      try {
        const up = await fetch(target, {
          method: req.method === "HEAD" ? "HEAD" : "GET",
          headers: hdrs,
          redirect: "follow",
          signal: ac.signal,
        });
        clearTimeout(hdrTimer);
        if (up.ok || up.status === 206) {
          if (isSub) {
            res.statusCode = 200;
            res.setHeader("Content-Type", "text/plain; charset=utf-8");
            res.setHeader("Cache-Control", "public, max-age=86400");
            return res.end(await up.text());
          }
          const ct = String(up.headers.get("content-type") || "video/mp4").split(";")[0].trim();
          res.statusCode = up.status;
          res.setHeader("Content-Type", ct.includes("octet-stream") ? "video/mp4" : ct);
          res.setHeader("Accept-Ranges", "bytes");
          res.setHeader("Cache-Control", "public, max-age=3600");
          if (up.headers.get("content-length")) res.setHeader("Content-Length", up.headers.get("content-length"));
          if (up.headers.get("content-range")) res.setHeader("Content-Range", up.headers.get("content-range"));
          if (isDl) res.setHeader("Content-Disposition", "attachment; filename=\"" + dlName + "\"");
          if (req.method === "HEAD" || !up.body) return res.end();
          const stream = Readable.fromWeb(up.body);
          stream.on("error", () => { if (!res.writableEnded) res.end(); });
          res.on("close", () => {
            if (!res.writableEnded) {
              ac.abort();
              stream.destroy();
            }
          });
          return stream.pipe(res);
        }
        lastStatus = up.status;
        try { await up.body?.cancel(); } catch {}
      } catch {
        clearTimeout(hdrTimer);
      }
    }
    if (!isSub) {
      const okH2 = await tryHttp2Pipe(req, res, target, headerVariants[0], isDl, dlName);
      if (okH2) return;
    }
  }

  res.statusCode = 502;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify({ ok: false, error: "Upstream media unavailable", upstreamStatus: lastStatus }));
});

server.listen(PORT, "0.0.0.0", () => {
  console.log("CinePulse Stream Proxy listening on port " + PORT);
});
